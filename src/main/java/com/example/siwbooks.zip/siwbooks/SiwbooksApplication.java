package com.example.siwbooks;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SiwbooksApplication {

	public static void main(String[] args) {
		SpringApplication.run(SiwbooksApplication.class, args);
	}

}
