package com.example.siwbooks.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {

    @Bean
    SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
          // 1) Deshabilita CSRF para admitir POST sin token
          .csrf(csrf -> csrf.disable())
          // 2) Exige BASIC-AUTH en todos los /api/books/**
          .authorizeHttpRequests(auth -> auth
            .requestMatchers("/api/books/**").authenticated()
            .anyRequest().authenticated()
          )
          // 3) Habilita HTTP BASIC por defecto
          .httpBasic(Customizer.withDefaults());

        return http.build();
    }
}
