package com.example.siwbooks.service;

import com.example.siwbooks.model.Book;

public interface BookService {
    Book findById(Long id);
    Book update(Long id, Book book);
    void delete(Long id);
}
